package com.example.fitpal

data class Workout(val name: String, val duration: String, val difficulty: String)

